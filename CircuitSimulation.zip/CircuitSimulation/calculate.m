clc,clear
a=1;
b=-1;
% ��ȡ�ļ�
filePath = 'inputFile.txt';
fid = fopen(filePath, 'r');
if fid == -1
    error('�޷����ļ�');
end

lines = {};
tline = fgetl(fid);
while ischar(tline)
    lines{end+1} = tline;
    tline = fgetl(fid);
end
fclose(fid);

Total_Lines = numel(lines);
Element_Lines = 1;
Total_Points = 1;
Source_U_Lines = 0;
Source_I_Lines = 0;
Tree_Info = zeros(Total_Points - 1, 1);
Tree_Mark = zeros(Total_Points, 1);

% �����ı�
for Tool_Number1 = 1:Total_Lines
    Total_Info{Tool_Number1} = lines{Tool_Number1};
end

for Tool_Number1 = 1:Total_Lines
    Tool_Info = Total_Info{Tool_Number1}(1);
    Tool_Number2 = 1;
    Element_Name{Tool_Number1} = Tool_Info;
    Tool_Number2 = Tool_Number2 + 1;
    while Total_Info{Tool_Number1}(Tool_Number2) ~= ' '
        Element_Name{Tool_Number1} = [Element_Name{Tool_Number1}, Total_Info{Tool_Number1}(Tool_Number2)];
        Tool_Number2 = Tool_Number2 + 1;
    end
    
    Tool_Number2 = Tool_Number2 + 1;
    Element_First(Tool_Number1) = 0;
    
    while Total_Info{Tool_Number1}(Tool_Number2) ~= ' '
        Tool_Tran = Total_Info{Tool_Number1}(Tool_Number2);
        Element_First(Tool_Number1) = Element_First(Tool_Number1) * 10 + str2double(Tool_Tran);
        Tool_Number2 = Tool_Number2 + 1;
    end
    
    Tool_Number2 = Tool_Number2 + 1;
    Element_Last(Tool_Number1) = 0;
    
    while Total_Info{Tool_Number1}(Tool_Number2) ~= ' '
        Tool_Tran = Total_Info{Tool_Number1}(Tool_Number2);
        Element_Last(Tool_Number1) = Element_Last(Tool_Number1) * 10 + str2double(Tool_Tran);
        Tool_Number2 = Tool_Number2 + 1;
    end
    
    Tool_Number2 = Tool_Number2 + 1;
    Tool_Info = Total_Info{Tool_Number1}(Tool_Number2);
    Tool_Number2 = Tool_Number2 + 1;
    Element_Value{Tool_Number1} = Tool_Info;
    
    while Tool_Number2 <= length(Total_Info{Tool_Number1})
        Element_Value{Tool_Number1} = [Element_Value{Tool_Number1}, Total_Info{Tool_Number1}(Tool_Number2)];
        Tool_Number2 = Tool_Number2 + 1;
    end
end

for Tool_Number1 = 2:Total_Lines
    Tool_Number3 = 1;
    
    for Tool_Number2 = 1:(Tool_Number1 - 1)
        if (Element_First(Tool_Number1) == Element_First(Tool_Number2) && Element_Last(Tool_Number1) == Element_Last(Tool_Number2)) || ...
           (Element_First(Tool_Number1) == Element_Last(Tool_Number2) && Element_Last(Tool_Number1) == Element_First(Tool_Number2))
            Tool_Number3 = 0;
        end
    end
    
    Element_Lines = Element_Lines + Tool_Number3;
    
    if Element_First(Tool_Number1) > Total_Points
        Total_Points = Element_First(Tool_Number1);
    end
    
    if Element_Last(Tool_Number1) > Total_Points
        Total_Points = Element_Last(Tool_Number1);
    end
end

% ���� Brunch ����
Tool_Number2 = 1;
Brunch_First(Tool_Number2) = Element_First(1);
Brunch_Last(Tool_Number2) = Element_Last(1);
Tool_Number2 = Tool_Number2 + 1;

for Tool_Number1 = 2:Total_Lines
    Tool_Number4 = 0;
    
    for Tool_Number3 = 1:Tool_Number1-1 
        if (Element_First(Tool_Number1) == Element_First(Tool_Number3) && Element_Last(Tool_Number1) == Element_Last(Tool_Number3)) || (Element_First(Tool_Number1) == Element_Last(Tool_Number3) && Element_Last(Tool_Number1) == Element_First(Tool_Number3))
            Tool_Number4 = 1;
        end
    end
    
    if Tool_Number4 == 0
        Brunch_First(Tool_Number2) = Element_First(Tool_Number1);
        Brunch_Last(Tool_Number2) = Element_Last(Tool_Number1);
        Tool_Number2 = Tool_Number2 + 1;
    end
end



% ��� Compute_A ����
for Tool_Number1 = 1:(Total_Points - 1)
    for Tool_Number2 = 1:Element_Lines
        if Brunch_First(Tool_Number2) == Tool_Number1
            Compute_A(Tool_Number1, Tool_Number2) = 1;
        elseif Brunch_Last(Tool_Number2) == Tool_Number1
            Compute_A(Tool_Number1, Tool_Number2) = -1;
        else
            Compute_A(Tool_Number1, Tool_Number2) = 0;
        end
    end
end

% ��ʼ�� Tree_Info �� Tree_Mark ����
Tree_Info = zeros(Total_Points - 1, 1);
Tree_Mark = zeros(Total_Points, 1);
Tool_Number3 = 1;
Tree_Info(1) = 1;
Tree_Mark(Brunch_First(1)) = 1;
Tree_Mark(Brunch_Last(1)) = 1;

% ���� Tree_Info ����
for Tool_Number1 = 2:Element_Lines
    for Tool_Number2 = 1:Element_Lines
        if (Tree_Mark(Brunch_First(Tool_Number2)) + Tree_Mark(Brunch_Last(Tool_Number2)) == 1)
            Tool_Number3 = Tool_Number3 + 1;
            Tree_Info(Tool_Number3) = Tool_Number2 ;
            Tree_Mark(Element_First(Tool_Number2)) = 1;
            Tree_Mark(Element_Last(Tool_Number2)) = 1;
        end
        
        if Tool_Number3 == Total_Points
            break;
        end
    end
end
% ��ʼ�� Compute_Bf ����

Compute_Bf = zeros(Element_Lines - Total_Points + 1, Element_Lines);

% ���� Tree_Off ����
Tree_Off = zeros(Element_Lines - Total_Points + 1, 1);

% ���� Tree_Point ����
Tree_Point = zeros(Element_Lines - Total_Points + 1,Total_Points);
Tool_Number1 = 1;

for Tool_Number2 = 1:Element_Lines
    Tool_Number4 = 0;
    
    for Tool_Number3 = 1:(Total_Points - 1)
        if Tree_Info(Tool_Number3) == Tool_Number2
            Tool_Number4 = 1;
        end
    end
    
    if Tool_Number4 == 0
        Tree_Off(Tool_Number1) = Tool_Number2;
        Compute_Bf(Tool_Number1,Tool_Number2)=1;
        Tool_Number1 = Tool_Number1 + 1;
    end
end

for Tool_Number1 = 1:(Element_Lines - Total_Points + 1)
    for Tool_Number2 = 1:Total_Points
        if (Brunch_First(Tree_Off(Tool_Number1)) == Tool_Number2 || Brunch_Last(Tree_Off(Tool_Number1)) == Tool_Number2)
            Tree_Point(Tool_Number1,Tool_Number2) = 1;
        else
            Tree_Point(Tool_Number1,Tool_Number2) = 0;
        end
    end

    for Tool_Number2 = 1:(Total_Points - 1)
        Tree_Mark(Tool_Number2) = 1;

        for Tool_Number3 = 1:Total_Points
            if (Element_First(Tree_Info(Tool_Number2)) == Tool_Number3 || Element_Last(Tree_Info(Tool_Number2)) == Tool_Number3)
                Tree_Point(Tool_Number1,Tool_Number3) = Tree_Point(Tool_Number1,Tool_Number3) + 1;
            end
        end
    end

    for Tool_Number2 = 1:Total_Points
        for Tool_Number3 = 1:Total_Points
            if Tree_Point(Tool_Number1,Tool_Number3) == 1
                for Tool_Number4 = 1:(Total_Points - 1)
                    if ((Brunch_First(Tree_Info(Tool_Number4))) == Tool_Number3 || (Brunch_Last(Tree_Info(Tool_Number4))) == Tool_Number3)
                        Tree_Point(Tool_Number1,Brunch_First(Tree_Info(Tool_Number4)))=Tree_Point(Tool_Number1,Brunch_First(Tree_Info(Tool_Number4)))-1;
                        Tree_Point(Tool_Number1,Brunch_Last(Tree_Info(Tool_Number4)))=Tree_Point(Tool_Number1,Brunch_Last(Tree_Info(Tool_Number4)))-1;
                        Tree_Mark(Tree_Info(Tool_Number4))=0;
                    end
                end
            end
        end
    end

    


    for Tool_Number2 = 1:(Total_Points - 1)
        Compute_Bf(Tool_Number1, Tree_Info(Tool_Number2) ) = Tree_Mark(Tool_Number2);
    end
end

for Tool_Number1 = 1:(Element_Lines - Total_Points + 1)
    for Tool_Number2 = 1:(Total_Points - 1)
        Element_Mark(Tool_Number2)=0;
    end
    Select_First=Brunch_First(Tree_Off(Tool_Number1));
    Select_Last=Brunch_Last(Tree_Off(Tool_Number1));
    for Tool_Number2 = 1:(Total_Points - 1)
        for Tool_Number3 = 1:(Total_Points - 1)
            if Select_First==Brunch_Last(Tree_Info(Tool_Number3))&&Element_Mark(Tool_Number3)==0
                Compute_Bf(Tool_Number1,Tree_Info(Tool_Number3))=1;
                Element_Mark(Tool_Number3)=1;
                Select_First=Brunch_First(Tree_Info(Tool_Number3));
            end
            if Select_First==Brunch_First(Tree_Info(Tool_Number3))&&Element_Mark(Tool_Number3)==0
                Compute_Bf(Tool_Number1,Tree_Info(Tool_Number3))=-1;
                Element_Mark(Tool_Number3)=1;
                Select_First=Brunch_Last(Tree_Info(Tool_Number3));
            end
            if Select_Last==Brunch_First(Tree_Info(Tool_Number3))&&Element_Mark(Tool_Number3)==0
                Compute_Bf(Tool_Number1,Tree_Info(Tool_Number3))=1;
                Element_Mark(Tool_Number3)=1;
                Select_Last=Brunch_Last(Tree_Info(Tool_Number3));
            end
            if Select_Last==Brunch_Last(Tree_Info(Tool_Number3))&&Element_Mark(Tool_Number3)==0
                Compute_Bf(Tool_Number1,Tree_Info(Tool_Number3))=-1;
                Element_Mark(Tool_Number3)=1;
                Select_Last=Brunch_First(Tree_Info(Tool_Number3));
            end
        end
    end
end

% �����迹����͵�ѹ��������

syms s;
syms t;
for Tool_Number1 = 1:Element_Lines
    for Tool_Number2 = 1:Element_Lines
        if Tool_Number1==Tool_Number2
            Compute_Zs(Tool_Number1,Tool_Number2)=s;

        else
            Compute_Zs(Tool_Number1,Tool_Number2)=0;
        end
    end
end
for Tool_Number1 = 1:Element_Lines    
    for Tool_Number2 = 1:Total_Lines
        if Brunch_First(Tool_Number1)==Element_First(Tool_Number2)&&Brunch_Last(Tool_Number1)==Element_Last(Tool_Number2)
            if Total_Info{Tool_Number1}(1)=="R"
                Compute_Zs(Tool_Number1,Tool_Number1)=str2double(Element_Value(Tool_Number1));
            elseif Total_Info{Tool_Number1}(1)=="L"
                Compute_Zs(Tool_Number1,Tool_Number1)=str2double(Element_Value(Tool_Number1))*s;
            elseif Total_Info{Tool_Number1}(1)=="C"
                Compute_Zs(Tool_Number1,Tool_Number1)=1/str2double(Element_Value(Tool_Number1))/s;
            else
                Compute_Zs(Tool_Number1,Tool_Number1)=0;
            end
        end
    end
end
Tool_Number1=1;
for Tool_Number2 = 1:Total_Lines
    if Total_Info{Tool_Number2}(1)=="U"
        Tool_Number4=0;
        for Tool_Number3 = 1:Element_Lines
            if Element_First(Tool_Number2)==Brunch_First(Tool_Number3)&&Element_Last(Tool_Number2)==Brunch_Last(Tool_Number3)
                USource_Info(Tool_Number1)=Tool_Number3;
            elseif Element_First(Tool_Number2)==Brunch_Last(Tool_Number3)&&Element_Last(Tool_Number2)==Brunch_First(Tool_Number3)
                ISource_Info(Tool_Number1)=Tool_Number3;
                Tool_Number4=1;
            end
        end
        Tool_Tran=strrep(Element_Value(Tool_Number2), 'sin', '*sin');
        Tool_Tran=strrep((Tool_Tran), 't', '*t');
        Tool_Tran=str2sym(Tool_Tran);
        USource_Value(Tool_Number1)=eval(Tool_Tran);
        if Tool_Number4==1
            USource_Value(Tool_Number1)=-USource_Value(Tool_Number1);
        end
        Tool_Number1=Tool_Number1+1;
    end
end
USource_Lines=Tool_Number1-1;
Tool_Number1=1;
for Tool_Number2 = 1:Total_Lines
    if Total_Info{Tool_Number2}(1)=="I"
        Tool_Number4=0;
        for Tool_Number3 = 1:Element_Lines
            if Element_First(Tool_Number2)==Brunch_First(Tool_Number3)&&Element_Last(Tool_Number2)==Brunch_Last(Tool_Number3)
                ISource_Info(Tool_Number1)=Tool_Number3;
            elseif Element_First(Tool_Number2)==Brunch_Last(Tool_Number3)&&Element_Last(Tool_Number2)==Brunch_First(Tool_Number3)
                ISource_Info(Tool_Number1)=Tool_Number3;
                Tool_Number4=1;
            end
        end
        Tool_Tran=strrep(Element_Value(Tool_Number2), 'sin', '*sin');
        Tool_Tran=strrep((Tool_Tran), 't', '*t');
        Tool_Tran=str2sym(Tool_Tran);
        ISource_Value(Tool_Number1)=eval(Tool_Tran);
        if Tool_Number4==1
            ISource_Value(Tool_Number1)=-ISource_Value(Tool_Number1);
        end
        Tool_Number1=Tool_Number1+1;
    end
end
ISource_Lines=Tool_Number1-1;
for Tool_Number1 = 1:Element_Lines
    Compute_Us(Tool_Number1)=t;
    Compute_Is(Tool_Number1)=t;
end
for Tool_Number1 = 1:Element_Lines
    for Tool_Number2 = 1:USource_Lines
        if USource_Info(Tool_Number2)==Tool_Number1
            Compute_Us(Tool_Number1)=USource_Value(Tool_Number2);
        end
    end
    for Tool_Number2 = 1:ISource_Lines
        if ISource_Info(Tool_Number2)==Tool_Number1
            Compute_Is(Tool_Number1)=ISource_Value(Tool_Number2);
        end
    end
end
for Tool_Number1 = 1:Element_Lines
    if Compute_Us(Tool_Number1)==t
        Compute_Us(Tool_Number1)=0;
    end
    if Compute_Is(Tool_Number1)==t
        Compute_Is(Tool_Number1)=0;
    end
end
Compute_O=Compute_A*0;
Compute_K=inv([Compute_Bf*Compute_Zs;Compute_A]);
Compute_U=laplace(Compute_Us,t,s);
Compute_I=laplace(Compute_Is,t,s);
for Tool_Number1=1:Element_Lines
    Compute_U0(Tool_Number1,1)=Compute_U(Tool_Number1);
    Compute_I0(Tool_Number1,1)=Compute_I(Tool_Number1);
end
Result_II=(Compute_K*[Compute_Bf;Compute_O])*Compute_U0-(Compute_K*[Compute_Bf*Compute_Zs;Compute_O])*Compute_I0;
Result_Ib=ilaplace(Result_II,t,s);
Result_UU=Compute_Zs*(Result_II+Compute_I0)-Compute_U0;
Result_Ub=ilaplace(Result_UU,t,s);
Result_Pb=Result_Ib.*Result_Ub;
disp('֧·����Ϊ');
disp(Result_Ib);
disp('֧·��ѹΪ');
disp(Result_Ub);